﻿//
// Copyright (C) 2018 HCL Technologies Ltd.
// All right reserved.
// The information contained here in is confidential and proprietary to
// HCL Technologies Ltd. and forms part of the HCL Technologies
// C# library
//
// DESCRIPTION
// <App.xaml.cs>
// This class is responsible to start up and shutdown the application.
// </App.xaml.cs>
//
// CREATED BY : Mukuti Mohan P
//============================================================================
// REVISION HISTORY
// DATE                 AUTHOR            VERSION         CHANGE DESCRIPTION
// 04-Jun-2018          Mukuti Mohan P    1.0             Initial Version
//============================================================================
using FeederApp.UI.Views;
using FeederApp.UI.Views.ViewModels;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using log4net;
using log4net.Core;

namespace FeederApp.UI
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            // Setting of level can be configurable through application configuration file
            Logger.Log.ConfigLogger("Log.txt", Level.Error, 2, 5);

            MainWindow mainWindow = new MainWindow();
            GlobalVariables.MainWindowObject = mainWindow;
            MainWindowViewModel mainWindowViewModelObj = new MainWindowViewModel();
            mainWindow.Closing += mainWindow_Closing;
            mainWindow.DataContext = mainWindowViewModelObj;
            mainWindow.Show();
        }

        void mainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (Application.Current != null)
            {
                Application.Current.Shutdown();
            }
        }
    }
}
