﻿//
// Copyright (C) 2018 HCL Technologies Ltd.
// All right reserved.
// The information contained here in is confidential and proprietary to
// HCL Technologies Ltd. and forms part of the HCL Technologies
// C# library
//
// DESCRIPTION
// <CloseDialog.cs>
// To close dialog box
// </CloseDialog.cs>
//
// CREATED BY : Mukuti Mohan P
//============================================================================
// REVISION HISTORY
// DATE                 AUTHOR            VERSION         CHANGE DESCRIPTION
// 04-Jun-2018          Mukuti Mohan P    1.0             Initial Version
//============================================================================
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace FeederApp.UI.Helpers
{
    public static class CloseDialog
    {
        public static readonly DependencyProperty DialogResultProperty =
       DependencyProperty.RegisterAttached(
           "DialogResult",
           typeof(bool?),
           typeof(CloseDialog),
           new PropertyMetadata(DialogResultChanged));

        private static void DialogResultChanged(
            DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            var window = d as Window;
            if (window != null && window.IsVisible)
            {
                try
                {
                    window.DialogResult = e.NewValue as bool?;
                }
                catch
                {
                    if (window != null && window.IsVisible)
                        window.Close();
                }
            }
        }

        /// <summary>
        /// To set DialogResultProperty
        /// </summary>
        /// <param name="target"></param>
        /// <param name="value"></param>
        public static void SetDialogResult(Window target, bool? value)
        {
            if (target != null)
            {
                target.SetValue(DialogResultProperty, value);
            }
        }
    }
}
