﻿//
// Copyright (C) 2018 HCL Technologies Ltd.
// All right reserved.
// The information contained here in is confidential and proprietary to
// HCL Technologies Ltd. and forms part of the HCL Technologies
// C# library
//
// DESCRIPTION
// <CommentModel.cs>
// This class contains properties for comments on post.
// </CommentModel.cs>
//
// CREATED BY : Mukuti Mohan P
//============================================================================
// REVISION HISTORY
// DATE                 AUTHOR            VERSION         CHANGE DESCRIPTION
// 04-Jun-2018          Mukuti Mohan P    1.0             Initial Version
//============================================================================
using FeederApp.UI.Views.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FeederApp.UI.Models
{
    public class CommentModel : ViewModelBase
    {
        #region Fields

        private int _postId;
        private string _commentText;
        private int _userId;
        private string _userImageUrl;

        #endregion

        #region Properties

        public int PostId
        {
            get
            {
                return _postId;
            }
            set
            {
                if (value != _postId)
                {
                    _postId = value;
                    OnPropertyChanged("PostId");
                }
            }
        }

        public string CommentText
        {
            get
            {
                return _commentText;
            }
            set
            {
                if (value != _commentText)
                {
                    _commentText = value;
                    OnPropertyChanged("CommentText");
                }
            }
        }

        public int UserId
        {
            get
            {
                return _userId;
            }
            set
            {
                if (value != _userId)
                {
                    _userId = value;
                    OnPropertyChanged("UserId");
                }
            }
        }

        public string UserImageUrl
        {
            get
            {
                return _userImageUrl;
            }
            set
            {
                if (value != _userImageUrl)
                {
                    _userImageUrl = value;
                    OnPropertyChanged("UserImageUrl");
                }
            }
        }

        #endregion

        #region Constructor
        public CommentModel()
        { }

        #endregion
    }
}
