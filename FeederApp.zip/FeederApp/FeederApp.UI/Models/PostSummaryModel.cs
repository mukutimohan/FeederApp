﻿//
// Copyright (C) 2018 HCL Technologies Ltd.
// All right reserved.
// The information contained here in is confidential and proprietary to
// HCL Technologies Ltd. and forms part of the HCL Technologies
// C# library
//
// DESCRIPTION
// <PostSummaryModel.cs>
// This class contains properties for Post Summary.
// </PostSummaryModel.cs>
//
// CREATED BY : Mukuti Mohan P
//============================================================================
// REVISION HISTORY
// DATE                 AUTHOR            VERSION         CHANGE DESCRIPTION
// 04-Jun-2018          Mukuti Mohan P    1.0             Initial Version
//============================================================================
using FeederApp.UI.Views.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FeederApp.UI.Models
{
    public class PostSummaryModel : ViewModelBase
    {
        #region Fields

        private int _postId;
        private string _postTitle;

        #endregion

        #region Properties

        public int PostId
        {
            get
            {
                return _postId;
            }
            set
            {
                if (value != _postId)
                {
                    _postId = value;
                    OnPropertyChanged("PostId");
                }
            }
        }

        public string PostTitle
        {
            get
            {
                return _postTitle;
            }
            set
            {
                if (value != _postTitle)
                {
                    _postTitle = value;
                    OnPropertyChanged("PostTitle");
                }
            }
        }

        #endregion

        #region Constructor

        public PostSummaryModel()
        { }

        #endregion
    }
}
