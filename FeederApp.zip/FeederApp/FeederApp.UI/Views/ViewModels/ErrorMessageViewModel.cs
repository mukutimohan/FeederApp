﻿//
// Copyright (C) 2018 HCL Technologies Ltd.
// All right reserved.
// The information contained here in is confidential and proprietary to
// HCL Technologies Ltd. and forms part of the HCL Technologies
// C# library
//
// DESCRIPTION
// <ErrorMessageViewModel.cs>.
// This class will show error message pop up.
// </ErrorMessageViewModel.cs>.
//
// CREATED BY : Mukuti Mohan P
//============================================================================
// REVISION HISTORY
// DATE                 AUTHOR            VERSION         CHANGE DESCRIPTION
// 04-Jun-2018          Mukuti Mohan P    1.0             Initial Version
//============================================================================
using FeederApp.UI.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace FeederApp.UI.Views.ViewModels
{
    public class ErrorMessageViewModel : ViewModelEventBase
    {
        #region Fields

        private bool? _dialogResult;
        private string _messageText;
        private MessageBoxResult _messageResult;

        #endregion

        #region Properties

        /// <summary>
        /// Dialog result for the message box window
        /// </summary>
        public bool? DialogResult
        {
            get
            {
                return _dialogResult;
            }
            set
            {
                _dialogResult = value;
                OnPropertyChanged("DialogResult");
            }
        }

        /// <summary>
        /// Message Text to display in the message box
        /// </summary>
        public string MessageText
        {
            get { return _messageText; }
            set
            {
                _messageText = value;
                OnPropertyChanged("MessageText");
            }
        }

        /// <summary>
        /// MessageBox result
        /// </summary>
        public MessageBoxResult MessageResult
        {
            get { return _messageResult; }
        }

        #endregion

        #region Commands

        /// <summary>
        /// Cancel command
        /// </summary>
        private DelegateCommand _cancelCommand;
        public ICommand CancelCommand
        {
            get
            {
                if (_cancelCommand == null)
                {
                    _cancelCommand = new DelegateCommand(new Action(CancelCommandExecuted));
                }
                return _cancelCommand;
            }
        }

        #endregion

        #region Constructor

        /// <summary>
        /// ErrorMessage window viewmodel
        /// </summary>
        public ErrorMessageViewModel() { }

        #endregion

        #region Methods

        /// <summary>
        /// To execute cancel command
        /// </summary>
        private void CancelCommandExecuted()
        {
            _messageResult = MessageBoxResult.Cancel;
            DialogResult = false;
        }

        #endregion
    }
}
