﻿//
// Copyright (C) 2018 HCL Technologies Ltd.
// All right reserved.
// The information contained here in is confidential and proprietary to
// HCL Technologies Ltd. and forms part of the HCL Technologies
// C# library
//
// DESCRIPTION
//<ViewModelEventBase.cs>
//This class is base class for events. It provides support for screen navigation. If screen name is not null then it will raise an event to change user controls for screen navigation
//</ ViewModelEventBase.cs>. 
//
// CREATED BY : Mukuti Mohan P
//============================================================================
// REVISION HISTORY
// DATE                 AUTHOR            VERSION         CHANGE DESCRIPTION
// 04-Jun-2018          Mukuti Mohan P    1.0             Initial Version
//============================================================================
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FeederApp.UI.Views.ViewModels
{
    ///<summary>
    ///this class is for View Model Base class with events..
    /// It provides support for Screen Navigation
    /// </summary>
    public class ViewModelEventBase : ViewModelBase
    {
        //public event NavigateScreenHandler NavigateScreen;
        public event EventHandler<NavigateEventArgs> NavigateScreen;
        /// <summary>
        /// IF Screen name is not null then it will raise an event to change usercontrols
        /// </summary>
        /// <param name="screenName"></param>
        /// <param name="screenParams"></param>
        public void DoNavigation(ScreenName screenName, params string[] navigationParams)
        {
            if (NavigateScreen != null)
                NavigateScreen(this, new NavigateEventArgs(screenName, navigationParams));
        }
        /// <summary>
        /// To Check the screen can be navigated
        /// </summary>
        /// <returns></returns>
        public virtual bool CanNavigate()
        {
            return true;
        }
    }

    public enum ScreenName
    {
        WelcomeScreen,
        PostSummary,
        PostDetails
    }

    public class NavigateEventArgs : EventArgs
    {
        #region Members
        private string[] _screenParameters;
        private ScreenName _navigationScreenName;
        private string _screenName;
        #endregion

        #region Constructor
        public NavigateEventArgs(string screenName)
        {
            if (screenName != null)
            {
                this._screenName = screenName;
            }
        }
        public NavigateEventArgs(ScreenName screenName, params string[] screenParams)
        {
            _navigationScreenName = screenName;

            if (screenParams != null && screenParams.Length > 0)
            {
                _screenParameters = screenParams;
            }
        }
        #endregion

        #region Properties
        public ScreenName NavigationScreenName
        {
            get { return _navigationScreenName; }
        }

        public string ScreenName
        {
            get { return _screenName; }
            set { _screenName = value; }
        }
        #endregion

        public string[] ScreenParameters()
        {
            return _screenParameters;
        }

    }
}
