﻿//
// Copyright (C) 2018 HCL Technologies Ltd.
// All right reserved.
// The information contained here in is confidential and proprietary to
// HCL Technologies Ltd. and forms part of the HCL Technologies
// C# library
//
// DESCRIPTION
// <WelcomeWindowViewModel.cs>
// It binds to WelcomeWindow.
// </WelcomeWindowViewModel.cs>
//
// CREATED BY : Mukuti Mohan P
//============================================================================
// REVISION HISTORY
// DATE                 AUTHOR            VERSION         CHANGE DESCRIPTION
// 04-Jun-2018          Mukuti Mohan P    1.0             Initial Version
//============================================================================
using FeederApp.UI.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace FeederApp.UI.Views.ViewModels
{
    public class WelcomeWindowViewModel : ViewModelEventBase
    {
        #region Fields

        #endregion

        #region Properties

        #endregion

        #region Constuctor

        /// <summary>
        /// Welcome window viewmodel
        /// </summary>
        public WelcomeWindowViewModel()
        {

        }

        #endregion

        #region Command

        /// <summary>
        /// Command to continue with application
        /// </summary>
        private DelegateCommand _okCommand;
        public ICommand OkCommand
        {
            get
            {
                if (_okCommand == null)
                {
                    _okCommand = new DelegateCommand(ContinueApplication);
                }
                return _okCommand;
            }
        }

        #endregion

        #region Method

        /// <summary>
        /// To continue with application
        /// </summary>
        private void ContinueApplication()
        {
            DoNavigation(ScreenName.PostSummary);
        }

        #endregion
    }
}
