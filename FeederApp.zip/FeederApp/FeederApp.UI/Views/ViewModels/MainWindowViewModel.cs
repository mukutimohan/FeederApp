﻿//
// Copyright (C) 2018 HCL Technologies Ltd.
// All right reserved.
// The information contained here in is confidential and proprietary to
// HCL Technologies Ltd. and forms part of the HCL Technologies
// C# library
//
// DESCRIPTION
// <MainWindowViewModel.cs>
// It binds to MainWindow which is a master template throughout the application.
// </MainWindowViewModel.cs>
//
// CREATED BY : Mukuti Mohan P
//============================================================================
// REVISION HISTORY
// DATE                 AUTHOR            VERSION         CHANGE DESCRIPTION
// 04-Jun-2018          Mukuti Mohan P    1.0             Initial Version
//============================================================================
using FeederApp.UI.Views.ViewHandlers;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FeederApp.UI.Views.ViewModels
{
    public class MainWindowViewModel : ViewModelEventBase
    {
        #region Fields

        private static readonly ILog _mainWindowViewModelLogger = LogManager.GetLogger(typeof(MainWindowViewModel));

        private object _currentView;
        private WelcomeWindow _welcomeWindowView;
        private PostSummaryWindow _postSummaryWindowView;
        private PostDetailsWindow _postDetailsView;
        private ScreenName _currentScreenName;
        private WelcomeWindowViewModel _welcomeWindowVM;
        private PostSummaryViewModel _postSummaryVM;
        private PostDetailsViewModel _postDetailsVM;

        #endregion

        #region Properties

        public object CurrentView
        {
            get { return _currentView; }
            set
            {
                _currentView = value;
                OnPropertyChanged("CurrentView");
            }
        }

        #endregion

        #region Constuctor

        /// <summary>
        /// Main window viewmodel
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public MainWindowViewModel()
        {
            this.NavigateScreen += NavigateScreens;
            NavigateScreens(this, new NavigateEventArgs(ScreenName.WelcomeScreen));
        }

        #endregion

        #region Command


        #endregion

        #region Method

        /// <summary>
        /// It will update child user control and viewmodel acording to selection command
        /// </summary>
        /// <param name="sender">source</param>
        /// <param name="e">navigate event args</param>
        void NavigateScreens(object sender, NavigateEventArgs e)
        {
            try
            {
                System.Windows.Controls.UserControl userControl = null;
                ViewModelEventBase viewModel = null;

                switch (e.NavigationScreenName)
                {
                    case ScreenName.WelcomeScreen:
                        _welcomeWindowView = new Views.WelcomeWindow();
                        userControl = _welcomeWindowView;
                        _welcomeWindowVM = new WelcomeWindowViewModel();
                        viewModel = _welcomeWindowVM;
                        break;

                    case ScreenName.PostSummary:
                        _postSummaryWindowView = new Views.PostSummaryWindow();
                        userControl = _postSummaryWindowView;
                        _postSummaryVM = new PostSummaryViewModel();
                        viewModel = _postSummaryVM;
                        break;

                    case ScreenName.PostDetails:
                        _postDetailsView = new Views.PostDetailsWindow();
                        userControl = _postDetailsView;
                        _postDetailsVM = new PostDetailsViewModel(_postSummaryVM.SelectedPost);
                        viewModel = _postDetailsVM;
                        break;
                }

                //Rmove and add the navigate screen event from the view model if anything already registered
                viewModel.NavigateScreen -= new EventHandler<NavigateEventArgs>(NavigateScreens);
                viewModel.NavigateScreen += new EventHandler<NavigateEventArgs>(NavigateScreens);

                userControl.DataContext = viewModel;
                CurrentView = userControl;
                _currentScreenName = e.NavigationScreenName;
            }
            catch (Exception ex)
            {
                PopupHandler.ShowErrorMessageBox(Properties.Resources.ResourceManager.GetString("ERROR_OCCURRED")
                        + Environment.NewLine + ex.Message);

                _mainWindowViewModelLogger.Error(ex.Message);
            }
        }

        #endregion
    }
}
