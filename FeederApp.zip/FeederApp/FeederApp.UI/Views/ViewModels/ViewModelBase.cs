﻿//
// Copyright (C) 2018 HCL Technologies Ltd.
// All right reserved.
// The information contained here in is confidential and proprietary to
// HCL Technologies Ltd. and forms part of the HCL Technologies
// C# library
//
// DESCRIPTION
// <ViewModelBase.cs>
//It is a Base class for all ViewModel classes in the application. It provides support for property change notifications.
//</ViewModelBase.cs>
//
// CREATED BY : Mukuti Mohan P
//============================================================================
// REVISION HISTORY
// DATE                 AUTHOR            VERSION         CHANGE DESCRIPTION
// 04-Jun-2018          Mukuti Mohan P    1.0             Initial Version
//============================================================================
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace FeederApp.UI.Views.ViewModels
{
    ///<summary>
    ///Base class for all ViewModel classes in the application.
    /// It provides support for property change notifications 
    /// </summary>

    public abstract class ViewModelBase : INotifyPropertyChanged
    {
        #region Debugging Aides

        /// <summary>
        /// Warns the developer if this object does not have
        /// a public property with the specified name. This 
        /// method does not exist in a Release build.
        /// </summary>
        [Conditional("DEBUG")]
        [DebuggerStepThrough]
        public virtual void VerifyPropertyName(string propertyName)
        {
            // Verify that the property name matches a real,  
            // public, instance property on this object.
            if (TypeDescriptor.GetProperties(this)[propertyName] == null)
            {
                string msg = "Invalid property name: " + propertyName;

                if (this.ThrowOnInvalidPropertyName)
                    throw new ArgumentException(msg);
                else
                    Debug.Fail(msg);
            }
        }

        /// <summary>
        /// Returns whether an exception is thrown, or if a Debug.Fail() is used
        /// when an invalid property name is passed to the VerifyPropertyName method.
        /// The default value is false, but subclasses used by unit tests might 
        /// override this property's getter to return true.
        /// </summary>
        protected virtual bool ThrowOnInvalidPropertyName { get; private set; }

        #endregion // Debugging Aides

        #region INotifyPropertyChanged Members

        /// <summary>
        /// Raised when a property on this object has a new value.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Raises this object's PropertyChanged event.
        /// </summary>
        /// <param name="propertyName">The property that has a new value.</param>
        protected virtual void OnPropertyChanged(string propertyName)
        {
            this.VerifyPropertyName(propertyName);

            PropertyChangedEventHandler handler = this.PropertyChanged;
            if (handler != null)
            {
                var e = new PropertyChangedEventArgs(propertyName);
                handler(this, e);
            }
        }

        #endregion // INotifyPropertyChanged Members

        /// <summary>
        /// Mouse DoubleClick HAndler
        /// </summary>
        public static class MouseDoubleClick
        {
            static DependencyProperty CommandProperty =
               DependencyProperty.RegisterAttached("Command",
               typeof(ICommand),
               typeof(MouseDoubleClick),
               new UIPropertyMetadata(CommandChanged));

            static DependencyProperty CommandParameterProperty =
                DependencyProperty.RegisterAttached("CommandParameter",
                                                    typeof(object),
                                                    typeof(MouseDoubleClick),
                                                    new UIPropertyMetadata(null));

            public static void SetCommand(DependencyObject target, ICommand value)
            {
                if (target != null)
                    target.SetValue(CommandProperty, value);
            }

            public static void SetCommandParameter(DependencyObject target, object value)
            {
                if (target != null)
                    target.SetValue(CommandParameterProperty, value);
            }
            public static object GetCommandParameter(DependencyObject target)
            {
                if (target != null)
                {
                    return target.GetValue(CommandParameterProperty);
                }
                else
                {
                    return null;
                }
            }
            private static void CommandChanged(DependencyObject target, DependencyPropertyChangedEventArgs e)
            {
                Control control = target as Control;
                if (control != null)
                {
                    if ((e.NewValue != null) && (e.OldValue == null))
                    {
                        control.MouseDoubleClick += OnMouseDoubleClick;
                    }
                    else if ((e.NewValue == null) && (e.OldValue != null))
                    {
                        control.MouseDoubleClick -= OnMouseDoubleClick;
                    }
                }
            }
            private static void OnMouseDoubleClick(object sender, RoutedEventArgs e)
            {
                Control control = sender as Control;
                ICommand command = (ICommand)control.GetValue(CommandProperty);
                object commandParameter = control.GetValue(CommandParameterProperty);
                command.Execute(commandParameter);
            }
        }
    }
}
