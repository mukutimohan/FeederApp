﻿//
// Copyright (C) 2018 HCL Technologies Ltd.
// All right reserved.
// The information contained here in is confidential and proprietary to
// HCL Technologies Ltd. and forms part of the HCL Technologies
// C# library
//
// DESCRIPTION
// <GlobalVariable.cs>
// It provides global variables to be used through-out the application
//</GlobalVariable.cs>
//
// CREATED BY : Mukuti Mohan P
//============================================================================
// REVISION HISTORY
// DATE                 AUTHOR            VERSION         CHANGE DESCRIPTION
// 04-Jun-2018          Mukuti Mohan P    1.0             Initial Version
//============================================================================
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FeederApp.UI.Views.ViewModels
{
    public static class GlobalVariables
    {
        #region Properties

        /// <summary>
        /// MainWindow object
        /// </summary>
        public static object MainWindowObject { set; get; }

        #endregion
    }
}
