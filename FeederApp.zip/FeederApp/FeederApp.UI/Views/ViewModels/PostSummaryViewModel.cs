﻿//
// Copyright (C) 2018 HCL Technologies Ltd.
// All right reserved.
// The information contained here in is confidential and proprietary to
// HCL Technologies Ltd. and forms part of the HCL Technologies
// C# library
//
// DESCRIPTION
// <PostSummaryViewModel.cs>
// It binds to Post Summary screen. It provides functionality mentioned below
// Displays post summary
// Provides option to filter post summary by input text
// Provides option to navigate to Post Details screen
//</PostSummaryViewModel.cs>
//
// CREATED BY : Mukuti Mohan P
//============================================================================
// REVISION HISTORY
// DATE                 AUTHOR            VERSION         CHANGE DESCRIPTION
// 04-Jun-2018          Mukuti Mohan P    1.0             Initial Version
//============================================================================
using FeederApp.BC;
using FeederApp.UI.Helpers;
using FeederApp.UI.Models;
using FeederApp.UI.Views.ViewHandlers;
using log4net;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace FeederApp.UI.Views.ViewModels
{
    public class PostSummaryViewModel : ViewModelEventBase
    {
        #region Fields

        private static readonly ILog _postSummaryViewModelLogger = LogManager.GetLogger(typeof(PostSummaryViewModel));

        private FeederDataHandler _feederDataHandler;
        private ObservableCollection<PostSummaryModel> _postSummaries;
        private List<PostSummaryModel> _postSummaryList;
        private string _postFilterText;
        private PostSummaryModel _selectedPost;

        #endregion

        #region Properties

        public ObservableCollection<PostSummaryModel> PostSummaries
        {
            get
            {
                return _postSummaries;
            }
            set
            {
                if (value != _postSummaries)
                {
                    _postSummaries = value;
                    OnPropertyChanged("PostSummaries");
                }
            }
        }

        public string PostFilterText
        {
            get
            {
                return _postFilterText;
            }
            set
            {
                if (value != _postFilterText)
                {
                    _postFilterText = value;
                    OnPropertyChanged("PostFilterText");
                    FilterPostSummary();
                }
            }
        }

        public PostSummaryModel SelectedPost
        {
            get
            {
                return _selectedPost;
            }
            set
            {
                if (value != _selectedPost)
                {
                    _selectedPost = value;
                    OnPropertyChanged("SelectedPost");

                    if (_selectedPost != null)
                    {
                        PostSelectionCommand.Execute(_selectedPost);
                    }
                }
            }
        }

        #endregion

        #region Constuctor

        /// <summary>
        /// PostSummary window viewmodel
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public PostSummaryViewModel()
        {
            _feederDataHandler = new FeederDataHandler();
            PostSummaries = new ObservableCollection<PostSummaryModel>();
            _postSummaryList = new List<PostSummaryModel>();

            LoadPostSummary();
        }

        #endregion

        #region Command

        /// <summary>
        /// Command to navigate to Post Details screen on tap / click post
        /// </summary>
        private DelegateCommand _postSelectionCommand;
        public ICommand PostSelectionCommand
        {
            get
            {
                if (_postSelectionCommand == null)
                {
                    _postSelectionCommand = new DelegateCommand(OnPostSelected);
                }
                return _postSelectionCommand;
            }
        }

        #endregion

        #region Method

        /// <summary>
        /// To load post summaries
        /// </summary>
        private void LoadPostSummary()
        {
            // Show loading window
            PopupHandler.ShowLoadingWindow();
            // Display post summaries
            Task.Factory.StartNew(() => DisplayPostSummary());
        }

        /// <summary>
        /// To display post summaries
        /// </summary>
        private void DisplayPostSummary()
        {
            try
            {
                // Get Post Summaries
                List<Tuple<int, string>> postSummaries = _feederDataHandler.GetPostSummaries();

                lock (PostSummaries)
                {
                    Application.Current.Dispatcher.Invoke((Action)delegate
                    {
                        if (postSummaries != null && postSummaries.Count > 0)
                        {
                            // Add Post Summaries to collection
                            foreach (Tuple<int, string> postSummaryItem in postSummaries)
                            {
                                _postSummaryList.Add(new PostSummaryModel()
                                {
                                    PostId = postSummaryItem.Item1,
                                    PostTitle = postSummaryItem.Item2
                                });

                                PostSummaries.Add(new PostSummaryModel()
                                {
                                    PostId = postSummaryItem.Item1,
                                    PostTitle = postSummaryItem.Item2
                                });
                            }
                        }

                        // Close loading window
                        PopupHandler.CloseLoadingWindow();
                    });
                }
            }
            catch (Exception ex)
            {
                Application.Current.Dispatcher.Invoke((Action)delegate
                {
                    // Close loading window
                    PopupHandler.CloseLoadingWindow();
                    // Display error message
                    PopupHandler.ShowErrorMessageBox(Properties.Resources.ResourceManager.GetString("ERROR_OCCURRED")
                        + Environment.NewLine + ex.Message);
                    // Load post summaries
                    LoadPostSummary();
                });

                _postSummaryViewModelLogger.Error(ex.Message);
            }
        }

        /// <summary>
        /// To filter post summaries
        /// </summary>
        private void FilterPostSummary()
        {
            List<PostSummaryModel> filteredPostSummaries = new List<PostSummaryModel>();

            if (string.IsNullOrEmpty(PostFilterText))
            {
                // Clear post summaries
                PostSummaries.Clear();

                // Show all post summaries
                foreach (PostSummaryModel postSummary in _postSummaryList)
                {
                    PostSummaries.Add(postSummary);
                }
            }
            else
            {
                // Filter post summaries by search text
                filteredPostSummaries = _postSummaryList.Where(x => x.PostTitle.ToLower().IndexOf(PostFilterText.ToLower()) > -1).ToList();
                // Clear post summaries
                PostSummaries.Clear();
                // Show post summaries according to search result
                foreach (PostSummaryModel postSummary in filteredPostSummaries)
                {
                    PostSummaries.Add(postSummary);
                }
            }
        }

        /// <summary>
        /// To navigate to Post Details screen on tap / click post
        /// </summary>
        private void OnPostSelected()
        {
            base.DoNavigation(ScreenName.PostDetails);
        }

        #endregion
    }
}
