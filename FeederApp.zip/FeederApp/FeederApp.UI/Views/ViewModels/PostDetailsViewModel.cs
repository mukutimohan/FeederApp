﻿//
// Copyright (C) 2018 HCL Technologies Ltd.
// All right reserved.
// The information contained here in is confidential and proprietary to
// HCL Technologies Ltd. and forms part of the HCL Technologies
// C# library
//
// DESCRIPTION
// <PostDetailsViewModel.cs>
// It binds to Post Details screen. It provides functionality mentioned below
// Displays post details
// Provides option to go back to Post Summary screen
//</PostDetailsViewModel.cs>
//
// CREATED BY : Mukuti Mohan P
//============================================================================
// REVISION HISTORY
// DATE                 AUTHOR            VERSION         CHANGE DESCRIPTION
// 04-Jun-2018          Mukuti Mohan P    1.0             Initial Version
//============================================================================
using FeederApp.BC;
using FeederApp.UI.Helpers;
using FeederApp.UI.Models;
using FeederApp.UI.Views.ViewHandlers;
using log4net;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace FeederApp.UI.Views.ViewModels
{
    public class PostDetailsViewModel : ViewModelEventBase
    {
        #region Fields

        private static readonly ILog _postDetailsViewModelLogger = LogManager.GetLogger(typeof(PostDetailsViewModel));

        private FeederDataHandler _feederDataHandler;
        private int _postID;
        private PostModel _selectedPost;
        private UserModel _userDetails;
        private ObservableCollection<CommentModel> _comments;

        #endregion

        #region Properties

        public PostModel SelectedPost
        {
            get
            {
                return _selectedPost;
            }
            set
            {
                if (value != _selectedPost)
                {
                    _selectedPost = value;
                    OnPropertyChanged("SelectedPost");
                }
            }
        }

        public UserModel UserDetails
        {
            get
            {
                return _userDetails;
            }
            set
            {
                if (value != _userDetails)
                {
                    _userDetails = value;
                    OnPropertyChanged("UserDetails");
                }
            }
        }

        public ObservableCollection<CommentModel> Comments
        {
            get
            {
                return _comments;
            }
            set
            {
                if (value != _comments)
                {
                    _comments = value;
                    OnPropertyChanged("Comments");
                }
            }
        }

        #endregion

        #region Constuctor

        /// <summary>
        /// PostDetails window viewmodel
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public PostDetailsViewModel(PostSummaryModel postSummary)
        {
            _feederDataHandler = new FeederDataHandler();
            _postID = postSummary.PostId;
            SelectedPost = null;
            Comments = new ObservableCollection<CommentModel>();
            // Show loading window
            PopupHandler.ShowLoadingWindow();
            Task.Factory.StartNew(() => LoadPostDetails());
        }

        #endregion

        #region Command

        /// <summary>
        /// Command to go back to Post Summary screen
        /// </summary>
        private DelegateCommand _backCommand;
        public ICommand BackCommand
        {
            get
            {
                if (_backCommand == null)
                {
                    _backCommand = new DelegateCommand(GoBack);
                }
                return _backCommand;
            }
        }

        #endregion

        #region Method

        /// <summary>
        /// To load post details
        /// </summary>
        private void LoadPostDetails()
        {
            try
            {
                Tuple<int, string, string, string> user = null;
                // Get the post
                Tuple<int, string, string, int> post = _feederDataHandler.GetPost(_postID);
                // Get comments on the post
                List<Tuple<int, string, int>> allComments = _feederDataHandler.GetComments(_postID);
                // Get all users
                List<Tuple<int, string, string, string>> allUsers = _feederDataHandler.GetUsers();

                Application.Current.Dispatcher.Invoke((Action)delegate
                {
                    if (post != null)
                    {
                        SelectedPost = new PostModel()
                        {
                            PostId = post.Item1,
                            PostTitle = post.Item2,
                            PostBody = post.Item3,
                            UserId = post.Item4
                        };
                    }

                    if (allUsers != null && allUsers.Count > 0)
                    {
                        // Collect information of post user
                        user = allUsers.Where(u => u.Item1 == SelectedPost.UserId).FirstOrDefault();

                        if (user != null)
                        {
                            UserDetails = new UserModel()
                            {
                                UserId = user.Item1,
                                UserName = user.Item2,
                                ImageUrl = GetUserImageUrl(user.Item3),
                                Email = user.Item4
                            };
                        }

                        // Collect all coments on the post and commenter information
                        if (allComments != null && allComments.Count > 0)
                        {
                            foreach (Tuple<int, string, int> comentOnPost in allComments)
                            {
                                user = allUsers.Where(u => u.Item1 == comentOnPost.Item3).FirstOrDefault();

                                Comments.Add(new CommentModel()
                                {
                                    PostId = comentOnPost.Item1,
                                    CommentText = comentOnPost.Item2,
                                    UserId = comentOnPost.Item3,
                                    UserImageUrl = user == null ? string.Empty : GetUserImageUrl(user.Item3)
                                });
                            }
                        }
                    }

                    // Close loading window
                    PopupHandler.CloseLoadingWindow();
                });
            }
            catch (Exception ex)
            {
                Application.Current.Dispatcher.Invoke((Action)delegate
                {
                    // Close loading window
                    PopupHandler.CloseLoadingWindow();
                    // Display error message
                    PopupHandler.ShowErrorMessageBox(Properties.Resources.ResourceManager.GetString("ERROR_OCCURRED")
                        + Environment.NewLine + ex.Message);
                    // Go back to Post Summary
                    GoBack();
                });

                _postDetailsViewModelLogger.Error(ex.Message);
            }
        }

        /// <summary>
        /// To get user image url
        /// </summary>
        /// <param name="imageUrl"></param>
        /// <returns></returns>
        private string GetUserImageUrl(string imageUrl)
        {
            string returnImageUri = imageUrl;
            int lastIndex = 0;
            int secondlastIndex = 0;

            if (!string.IsNullOrEmpty(imageUrl))
            {
                lastIndex = imageUrl.LastIndexOf('/');
                if (lastIndex > -1)
                {
                    secondlastIndex = imageUrl.Substring(0, lastIndex - 1).LastIndexOf('/');

                    if (secondlastIndex > -1)
                    {
                        returnImageUri = imageUrl.Substring(0, secondlastIndex);
                    }
                }
            }

            return returnImageUri;
        }

        /// <summary>
        /// To go back to Post Summary screen
        /// </summary>
        private void GoBack()
        {
            base.DoNavigation(ScreenName.PostSummary);
        }

        #endregion
    }
}
