﻿//
// Copyright (C) 2018 HCL Technologies Ltd.
// All right reserved.
// The information contained here in is confidential and proprietary to
// HCL Technologies Ltd. and forms part of the HCL Technologies
// C# library
//
// DESCRIPTION
// <PopupHandler.cs>
// This class will handle all the popup displays through-out the application.
// </PopupHandler.cs>
//
// CREATED BY : Mukuti Mohan P
//============================================================================
// REVISION HISTORY
// DATE                 AUTHOR            VERSION         CHANGE DESCRIPTION
// 04-Jun-2018          Mukuti Mohan P    1.0             Initial Version
//============================================================================
using FeederApp.UI.Views.ViewModels;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace FeederApp.UI.Views.ViewHandlers
{
    class PopupHandler
    {
        #region Fields

        private static readonly ILog _popupHandlerLogger = LogManager.GetLogger(typeof(PopupHandler));

        #endregion        

        #region Methods

        /// <summary>
        /// To Check the animation is fadein/out
        /// </summary>
        private static bool _isFadeIn;

        public static void ShowLoadingWindow()
        {
            System.Windows.Application.Current.Dispatcher.Invoke(() =>
            {
                if (GlobalVariables.MainWindowObject != null)
                {
                    var mainwindow = (MainWindow)GlobalVariables.MainWindowObject;
                    if (mainwindow != null && mainwindow.Visibility == Visibility.Visible)
                    {
                        FadeAnimation(true);
                    }
                }
            });
        }

        public static void CloseLoadingWindow()
        {
            FadeAnimation(false);

            if (GlobalVariables.MainWindowObject != null)
            {
                MainWindow mainObj = GlobalVariables.MainWindowObject as MainWindow;
                Rectangle fadeRectangle = mainObj.FadeRectangle;
                fadeRectangle.Visibility = Visibility.Collapsed;
                mainObj.CurrentScreenView.Visibility = Visibility.Visible;
            }
        }

        /// <summary>
        /// Fade - in / out animation 
        /// </summary>
        /// <param name="isFadeIn">is that Fadein/Fade Out</param>
        private static void FadeAnimation(bool isFadeIn)
        {
            if (GlobalVariables.MainWindowObject != null && GlobalVariables.MainWindowObject is MainWindow)
            {
                MainWindow mainObj = GlobalVariables.MainWindowObject as MainWindow;
                mainObj.CurrentScreenView.Visibility = Visibility.Hidden;
                Rectangle fadeRectangle = mainObj.FadeRectangle;
                fadeRectangle.Visibility = Visibility.Visible;
                Storyboard storyBoard = new Storyboard();
                DoubleAnimation doubleAnimation = new DoubleAnimation();
                _isFadeIn = isFadeIn;
                //For Fade-in animation
                if (isFadeIn)
                {
                    doubleAnimation.From = 0;
                    doubleAnimation.To = 0.7;
                }
                //For fadeout animation
                else
                {
                    doubleAnimation.From = 0.7;
                    doubleAnimation.To = 0;
                }
                doubleAnimation.Duration = new Duration(new TimeSpan(0, 0, 0, 0, 0)); // Duration set to 0 to remove animation
                Storyboard.SetTargetName(doubleAnimation, fadeRectangle.Name);
                Storyboard.SetTargetProperty(doubleAnimation, new PropertyPath(Rectangle.OpacityProperty));
                storyBoard.Children.Add(doubleAnimation);
                storyBoard.Completed += new EventHandler(storyBoard_Completed);
                storyBoard.Begin(mainObj);
            }
        }

        /// <summary>
        /// Fade Animation story board completion event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        static void storyBoard_Completed(object sender, EventArgs e)
        {
            if (!_isFadeIn)
            {
                MainWindow mainObj = GlobalVariables.MainWindowObject as MainWindow;
                Rectangle fadeRectangle = mainObj.FadeRectangle;
                fadeRectangle.Visibility = Visibility.Collapsed;
            }
        }

        /// <summary>
        /// To Display the custom message box with all buttons
        /// </summary>
        /// <param name="message">Message Text to display</param>
        /// <param name="messageBoxIconType">Icon type in the screen</param>
        /// <param name="messageBoxButtons">Message box button options to display</param>
        /// <returns></returns>
        public static MessageBoxResult ShowErrorMessageBox(string message)
        {
            MessageBoxResult returnValue = MessageBoxResult.None;

            try
            {
                System.Windows.Application.Current.Dispatcher.Invoke(() =>
                {
                    ErrorMessageWindow msgWindow = new ErrorMessageWindow();
                    ErrorMessageViewModel msgViewModel = new ErrorMessageViewModel();
                    if (!string.IsNullOrEmpty(message))
                    {
                        msgViewModel.MessageText = message;
                    }

                    msgWindow.DataContext = msgViewModel;
                    ShowErrorPopup(msgWindow);
                    returnValue = msgViewModel.MessageResult;
                });
            }
            catch (Exception ex)
            {
                _popupHandlerLogger.Error(ex.Message);
            }

            return returnValue;
        }

        public static void ShowErrorPopup(Window errorMessageWindow)
        {
            try
            {
                if (errorMessageWindow != null)
                {
                    if (GlobalVariables.MainWindowObject != null)
                    {
                        var mainwindow = (MainWindow)GlobalVariables.MainWindowObject;
                        if (mainwindow != null && mainwindow.Visibility == Visibility.Visible)
                            errorMessageWindow.Owner = mainwindow;
                    }
                    errorMessageWindow.ShowInTaskbar = false;
                    errorMessageWindow.WindowStartupLocation = WindowStartupLocation.CenterOwner;
                    errorMessageWindow.Activate();
                    errorMessageWindow.Focus();
                    errorMessageWindow.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                _popupHandlerLogger.Error(ex.Message);
            }
        }

        #endregion
    }
}
