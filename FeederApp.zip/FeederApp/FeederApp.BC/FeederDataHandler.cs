﻿//
// Copyright (C) 2018 HCL Technologies Ltd.
// All right reserved.
// The information contained here in is confidential and proprietary to
// HCL Technologies Ltd. and forms part of the HCL Technologies
// C# library
//
// DESCRIPTION
// <FeederDataHandler.cs>
// This class is responsible for handling all business requirements related operations.
// </FeederDataHandler.cs>
//
// CREATED BY : Mukuti Mohan P
//============================================================================
// REVISION HISTORY
// DATE                 AUTHOR            VERSION         CHANGE DESCRIPTION
// 04-Jun-2018          Mukuti Mohan P    1.0             Initial Version
//============================================================================
using FeederApp.DAC;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FeederApp.BC
{
    public class FeederDataHandler
    {
        #region Fields

        private static readonly ILog _feederDataHandlerLogger = LogManager.GetLogger(typeof(FeederDataHandler));

        #endregion

        #region Methods

        /// <summary>
        /// To get post summary information from DAL
        /// </summary>
        /// <returns>postSummaries</returns>
        public List<Tuple<int, string>> GetPostSummaries()
        {
            List<Tuple<int, string>> postSummaries = null;
            FeederDataProvider feederDataProvider;

            try
            {
                feederDataProvider = new FeederDataProvider();
                postSummaries = feederDataProvider.GetPostSummariesInfo();
            }
            catch (NullReferenceException nex)
            {
                // log the error.
                _feederDataHandlerLogger.Error(nex.Message);
                throw;
            }
            catch (Exception ex)
            {
                // log the error.
                _feederDataHandlerLogger.Error(ex.Message);
                throw;
            }

            return postSummaries;
        }

        /// <summary>
        /// To get all comments on a post from DAL
        /// </summary>
        /// <param name="postID"></param>
        /// <returns>comments</returns>
        public List<Tuple<int, string, int>> GetComments(int postID)
        {
            List<Tuple<int, string, int>> comments = null;
            FeederDataProvider feederDataProvider;

            try
            {
                feederDataProvider = new FeederDataProvider();
                comments = feederDataProvider.GetCommentsOnPost(postID);
            }
            catch (NullReferenceException nex)
            {
                // log the error.
                _feederDataHandlerLogger.Error(nex.Message);
                throw;
            }
            catch (Exception ex)
            {
                // log the error.
                _feederDataHandlerLogger.Error(ex.Message);
                throw;
            }

            return comments;
        }

        /// <summary>
        /// To get post details from DAL
        /// </summary>
        /// <param name="postID"></param>
        /// <returns>postDetails</returns>
        public Tuple<int, string, string, int> GetPost(int postID)
        {
            Tuple<int, string, string, int> postDetails = null;
            FeederDataProvider feederDataProvider;

            try
            {
                feederDataProvider = new FeederDataProvider();
                postDetails = feederDataProvider.GetPostDetails(postID);
            }
            catch (NullReferenceException nex)
            {
                // log the error.
                _feederDataHandlerLogger.Error(nex.Message);
                throw;
            }
            catch (Exception ex)
            {
                // log the error.
                _feederDataHandlerLogger.Error(ex.Message);
                throw;
            }

            return postDetails;
        }

        /// <summary>
        /// To get all users information from DAL
        /// </summary>
        /// <returns>users</returns>
        public List<Tuple<int, string, string, string>> GetUsers()
        {
            List<Tuple<int, string, string, string>> users = null;
            FeederDataProvider feederDataProvider;

            try
            {
                feederDataProvider = new FeederDataProvider();
                users = feederDataProvider.GetUsersInformation();
            }
            catch (NullReferenceException nex)
            {
                // log the error.
                _feederDataHandlerLogger.Error(nex.Message);
                throw;
            }
            catch (Exception ex)
            {
                // log the error.
                _feederDataHandlerLogger.Error(ex.Message);
                throw;
            }

            return users;
        }

        #endregion
    }
}
