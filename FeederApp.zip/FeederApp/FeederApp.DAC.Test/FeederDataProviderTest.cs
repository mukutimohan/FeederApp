﻿//
// Copyright (C) 2018 HCL Technologies Ltd.
// All right reserved.
// The information contained here in is confidential and proprietary to
// HCL Technologies Ltd. and forms part of the HCL Technologies
// C# library
//
// DESCRIPTION
// <FeederDataProviderTest.cs>
// This class consists of test cases to test methods in FeederDataProvider class.
// </FeederDataProviderTest.cs>
//
// CREATED BY : Mukuti Mohan P
//============================================================================
// REVISION HISTORY
// DATE                 AUTHOR            VERSION         CHANGE DESCRIPTION
// 04-Jun-2018          Mukuti Mohan P    1.0             Initial Version
//============================================================================
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace FeederApp.DAC.Test
{
    [TestClass]
    public class FeederDataProviderTest
    {
        FeederDataProvider _feederDataProvider = null;

        public FeederDataProviderTest()
        {
            _feederDataProvider = new FeederDataProvider();
        }

        [TestMethod]
        public void GetPostSummariesInfoTest()
        {
            List<Tuple<int, string>> posts = _feederDataProvider.GetPostSummariesInfo();
            Assert.IsNotNull(posts);
        }

        [TestMethod]
        public void GetCommentsOnPostTest()
        {
            List<Tuple<int, string, int>> comments = _feederDataProvider.GetCommentsOnPost(1);
            Assert.IsNotNull(comments);
        }

        [TestMethod]
        public void GetPostDetailsTest()
        {
            Tuple<int, string, string, int> post = _feederDataProvider.GetPostDetails(1);
            Assert.IsNotNull(post);
        }

        [TestMethod]
        public void GetUsersInformationTest()
        {
            List<Tuple<int, string, string, string>> users = _feederDataProvider.GetUsersInformation();
            Assert.IsNotNull(users);
        }
    }
}
