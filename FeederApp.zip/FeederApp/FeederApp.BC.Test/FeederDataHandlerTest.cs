﻿//
// Copyright (C) 2018 HCL Technologies Ltd.
// All right reserved.
// The information contained here in is confidential and proprietary to
// HCL Technologies Ltd. and forms part of the HCL Technologies
// C# library
//
// DESCRIPTION
// <FeederDataHandlerTest.cs>
// This class consists of test cases to test methods in FeederDataHandler class.
// </FeederDataHandlerTest.cs>
//
// CREATED BY : Mukuti Mohan P
//============================================================================
// REVISION HISTORY
// DATE                 AUTHOR            VERSION         CHANGE DESCRIPTION
// 04-Jun-2018          Mukuti Mohan P    1.0             Initial Version
//============================================================================
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace FeederApp.BC.Test
{
    [TestClass]
    public class FeederDataHandlerTest
    {
        FeederDataHandler _feederDataHandler = null;

        public FeederDataHandlerTest()
        {
            _feederDataHandler = new FeederDataHandler();
        }

        [TestMethod]
        public void GetPostSummariesTest()
        {
            List<Tuple<int, string>> posts = _feederDataHandler.GetPostSummaries();
            Assert.IsNotNull(posts);
        }

        [TestMethod]
        public void GetCommentsTest()
        {
            List<Tuple<int, string, int>> comments = _feederDataHandler.GetComments(2);
            Assert.IsNotNull(comments);
        }

        [TestMethod]
        public void GetPostTest()
        {
            Tuple<int, string, string, int> post = _feederDataHandler.GetPost(1);
            Assert.IsNotNull(post);
        }

        [TestMethod]
        public void GetUsersTest()
        {
            List<Tuple<int, string, string, string>> users = _feederDataHandler.GetUsers();
            Assert.IsNotNull(users);
        }
    }
}
