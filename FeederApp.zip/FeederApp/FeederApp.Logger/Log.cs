﻿//
// Copyright (C) 2018 HCL Technologies Ltd.
// All right reserved.
// The information contained here in is confidential and proprietary to
// HCL Technologies Ltd. and forms part of the HCL Technologies
// C# library
//
// DESCRIPTION
//<Log.cs>
// This class is responsible to initiate the log service with the defined log pattern. This is used through-out the application to log information into log file 
//</Log.cs>. 
//
//
// CREATED BY : Mukuti Mohan P
//============================================================================
// REVISION HISTORY
// DATE                 AUTHOR            VERSION         CHANGE DESCRIPTION
// 04-Jun-2018          Mukuti Mohan P    1.0             Initial Version
//============================================================================
using log4net;
using log4net.Appender;
using log4net.Core;
using log4net.Filter;
using log4net.Layout;
using log4net.Repository.Hierarchy;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FeederApp.Logger
{
    public static class Log
    {
        #region  Members
        /// <summary>
        /// The log pattern defined to log the details into log file
        /// </summary>
        public const string LOGPATTERN = "%date [%thread] %level  %c %method %m%n";
        private static readonly ILog _log = LogManager.GetLogger(typeof(Log));
        #endregion

        #region Method

        /// <summary>
        /// To configure logger
        /// </summary>
        /// <param name="filename">file name to be logged</param>
        /// <param name="minLogLevel">logging level</param>
        /// <param name="loggerMaxFileSize">max size for file</param>
        /// <param name="logFileCount">file count</param>
        /// <param name="logPattern">pattern to be logged</param>
        public static void ConfigLogger(string filename, Level minLogLevel, int loggerMaxFileSize, int logFileCount, string logPattern = "")
        {
            Hierarchy hierarchy = (Hierarchy)LogManager.GetRepository();
            LevelRangeFilter filter = new LevelRangeFilter();

            PatternLayout patternLayout = new PatternLayout();
            patternLayout.ConversionPattern = (!string.IsNullOrEmpty(logPattern)) ? logPattern : LOGPATTERN;
            patternLayout.ActivateOptions();

            RollingFileAppender roller = new RollingFileAppender();
            roller.AppendToFile = true;
            roller.File = filename;
            roller.Layout = patternLayout;
            roller.MaxSizeRollBackups = logFileCount;
            roller.MaximumFileSize = string.Format("{0}MB", loggerMaxFileSize);
            roller.AddFilter(filter);
            filter.LevelMin = minLogLevel;
            filter.LevelMax = Level.Fatal;
            roller.RollingStyle = RollingFileAppender.RollingMode.Size;
            roller.StaticLogFileName = true;
            roller.ActivateOptions();
            hierarchy.Root.AddAppender(roller);
            hierarchy.Configured = true;
            _log.Debug("Logger Configured");
        }
        #endregion
    }
}
