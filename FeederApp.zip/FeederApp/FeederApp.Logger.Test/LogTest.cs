﻿//
// Copyright (C) 2018 HCL Technologies Ltd.
// All right reserved.
// The information contained here in is confidential and proprietary to
// HCL Technologies Ltd. and forms part of the HCL Technologies
// C# library
//
// DESCRIPTION
// <LogTest.cs>
// This class consists of test cases to test methods in Log class.
// </LogTest.cs>
//
// CREATED BY : Mukuti Mohan P
//============================================================================
// REVISION HISTORY
// DATE                 AUTHOR            VERSION         CHANGE DESCRIPTION
// 04-Jun-2018          Mukuti Mohan P    1.0             Initial Version
//============================================================================
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FeederApp.Logger;
using System.IO;
using log4net;
using log4net.Appender;
using log4net.Core;
using log4net.Filter;
using log4net.Layout;
using log4net.Repository.Hierarchy;

namespace FeederApp.Logger.Test
{
    [TestClass]
    public class LogTest
    {
        [TestMethod]
        public void ConfigLoggerTestMethod()
        {
            string filename = @"D:\Logger.txt";
            Log.ConfigLogger(filename, log4net.Core.Level.Error, 2, 5, Log.LOGPATTERN);
            Assert.AreEqual(File.Exists(filename), true);
        }

        [TestMethod]
        public void ConfigLoggerTestMethodWithEmptyLogPattern()
        {
            string filename = @"D:\Logger.txt";
            Log.ConfigLogger(filename, log4net.Core.Level.Error, 2, 5);
            Assert.AreEqual(File.Exists(filename), true);

        }
    }
}
