﻿//
// Copyright (C) 2018 HCL Technologies Ltd.
// All right reserved.
// The information contained here in is confidential and proprietary to
// HCL Technologies Ltd. and forms part of the HCL Technologies
// C# library
//
// DESCRIPTION
// <FeederDataProvider.cs>
// This class is responsible to provide data to application from data repository.
// </FeederDataProvider.cs>
//
// CREATED BY : Mukuti Mohan P
//============================================================================
// REVISION HISTORY
// DATE                 AUTHOR            VERSION         CHANGE DESCRIPTION
// 04-Jun-2018          Mukuti Mohan P    1.0             Initial Version
//============================================================================
using Org.Feeder.FeederDb;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using log4net;

namespace FeederApp.DAC
{
    /// <summary>
    /// Provides database instance
    /// </summary>
    public sealed class FeederDatabase
    {
        static readonly FeederDatabase _instance = new FeederDatabase();
        public static FeederDatabase Instance
        {
            get
            {
                return _instance;
            }
        }

        private Database _feederDB;

        public Database FeederDB
        {
            get
            {
                return _feederDB;
            }
        }

        private FeederDatabase()
        {
            // Initialize.
            string connectionString;

            if (ConfigurationManager.ConnectionStrings["ConnectionString"] != null)
            {
                connectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
            }
            else
            {
                connectionString = "local";
            }

            _feederDB = new Database(connectionString);
        }
    }

    public class FeederDataProvider
    {
        #region Fields

        private static readonly ILog _feederDataProviderLogger = LogManager.GetLogger(typeof(FeederDataProvider));
        Database _feederDb;

        #endregion

        #region Constuctor

        public FeederDataProvider()
        {
            _feederDb = FeederDatabase.Instance.FeederDB;
        }

        #endregion

        #region Methods

        /// <summary>
        /// To get post summary information
        /// </summary>
        /// <returns>postSummaryList</returns>
        public List<Tuple<int, string>> GetPostSummariesInfo()
        {
            List<Tuple<int, string>> postSummaryList = new List<Tuple<int, string>>();
            List<PostSummary> postSummaries = null;

            try
            {
                postSummaries = _feederDb.GetPostSummaries().ToList();

                if (postSummaries != null && postSummaries.Count > 0)
                {
                    foreach (PostSummary postSummaryItem in postSummaries)
                    {
                        postSummaryList.Add(new Tuple<int, string>(postSummaryItem.Id, postSummaryItem.Title));
                    }
                }
            }
            //catching specific exceptions first.
            catch (SqlException sqe)
            {
                //log exception
                _feederDataProviderLogger.Error(sqe.Message);
                throw;
            }
            catch (Exception ex)
            {
                _feederDataProviderLogger.Error(ex.Message);
                throw;
            }

            return postSummaryList;
        }

        /// <summary>
        /// To get all comments on a post
        /// </summary>
        /// <param name="postID"></param>
        /// <returns>commentsList</returns>
        public List<Tuple<int, string, int>> GetCommentsOnPost(int postID)
        {
            List<Tuple<int, string, int>> commentsList = new List<Tuple<int, string, int>>();
            List<Comment> comments = null;

            try
            {
                comments = _feederDb.GetComments(postID).ToList();

                if (comments != null && comments.Count > 0)
                {
                    foreach (Comment commentItem in comments)
                    {
                        commentsList.Add(new Tuple<int, string, int>(commentItem.PostId, commentItem.Text, commentItem.UserId));
                    }
                }
            }
            
            //catching specific exceptions first.
            catch (SqlException sqe)
            {
                //log exception
                _feederDataProviderLogger.Error(sqe.Message);
                throw;
            }
            catch (Exception ex)
            {
                _feederDataProviderLogger.Error(ex.Message);
                throw;
            }

            return commentsList;
        }

        /// <summary>
        /// To get post details
        /// </summary>
        /// <param name="postID"></param>
        /// <returns>postDetails</returns>
        public Tuple<int, string, string, int> GetPostDetails(int postID)
        {
            Post post = null;
            Tuple<int, string, string, int> postDetails = null;

            try
            {
                post = _feederDb.GetPost(postID);

                if (post != null)
                {
                    postDetails = new Tuple<int, string, string, int>(post.Id, post.Title, post.Body, post.UserId);
                }
            }
            //catching specific exceptions first.
            catch (SqlException sqe)
            {
                //log exception
                _feederDataProviderLogger.Error(sqe.Message);
                throw;
            }
            catch (Exception ex)
            {
                _feederDataProviderLogger.Error(ex.Message);
                throw;
            }

            return postDetails;
        }

        /// <summary>
        /// To get all users information
        /// </summary>
        /// <returns>usersList</returns>
        public List<Tuple<int, string, string, string>> GetUsersInformation()
        {
            List<Tuple<int, string, string, string>> usersList = new List<Tuple<int, string, string, string>>();
            List<User> users = null;

            try
            {
                users = _feederDb.GetUsers().ToList();

                if (users != null && users.Count > 0)
                {
                    foreach (User user in users)
                    {
                        usersList.Add(new Tuple<int, string, string, string>(user.UserId, user.Name, user.ImageUrl, user.Email));
                    }
                }
            }
            //catching specific exceptions first.
            catch (SqlException sqe)
            {
                //log exception
                _feederDataProviderLogger.Error(sqe.Message);
                throw;
            }
            catch (Exception ex)
            {
                _feederDataProviderLogger.Error(ex.Message);
                throw;
            }

            return usersList;
        }

        #endregion
    }
}
